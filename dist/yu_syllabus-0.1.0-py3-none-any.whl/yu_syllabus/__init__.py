from yu_syllabus.GetUrlList import *
from yu_syllabus.FacultyDict import *
from yu_syllabus.get_element import *
